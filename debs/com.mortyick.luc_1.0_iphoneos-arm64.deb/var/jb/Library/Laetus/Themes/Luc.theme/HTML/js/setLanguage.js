(function(window, doc) {
    function iPX(){
        switch (CURRENT_LANGUAGE) {
            case 'en':
                STANDARD_KEY_WIDTH = 32;
                STANDARD_ROW_SPACING = 5;
                STANDARD_ROW_SPACING_NUMBERS = 5;
                SMALL_ROW_SPACING = 18;
                SMALL_ROW_SPACING_NUMBERS = 20;
                alphabet = alphabetUS;
                numbers = numbersUS;
                numbersCap = numbersCapUS;
            break;
            case 'nb':
                STANDARD_KEY_WIDTH = 30;
                STANDARD_ROW_SPACING = 4;
                STANDARD_ROW_SPACING_NUMBERS = 8;
                SMALL_ROW_SPACING = 18;
                SMALL_ROW_SPACING_NUMBERS = 22;
                alphabet = alphabetNB;
                numbers = numbersUS;
                numbersCap = numbersCapUS;
            break;
            case 'es':
                STANDARD_KEY_WIDTH = 32;
                STANDARD_ROW_SPACING = 5;
                STANDARD_ROW_SPACING_NUMBERS = 6;
                SMALL_ROW_SPACING = 18;
                SMALL_ROW_SPACING_NUMBERS = 20;
                alphabet = alphabetES;
                numbers = numbersUS;
                numbersCap = numbersCapUS;
            break;
            case 'zh':
                STANDARD_KEY_WIDTH = 32;
                STANDARD_ROW_SPACING = 5;
                STANDARD_ROW_SPACING_NUMBERS = 6;
                SMALL_ROW_SPACING = 18;
                SMALL_ROW_SPACING_NUMBERS = 13;
                alphabet = alphabetZH;
                numbers = numbersZH;
                numbersCap = numbersCapZH;
            break;
        
            default:
                break;
        }
        keyMaker.loadKeyset();
    }
    function iPXSMax(){
        switch (CURRENT_LANGUAGE) {
            case 'en':
                STANDARD_KEY_WIDTH = 32;
                STANDARD_ROW_SPACING = 9;
                STANDARD_ROW_SPACING_NUMBERS = 9;
                SMALL_ROW_SPACING = 18;
                SMALL_ROW_SPACING_NUMBERS = 25;
                alphabet = alphabetUS;
                numbers = numbersUS;
                numbersCap = numbersCapUS;
            break;
            case 'nb':
                STANDARD_KEY_WIDTH = 30;
                STANDARD_ROW_SPACING = 7;
                STANDARD_ROW_SPACING_NUMBERS = 11;
                SMALL_ROW_SPACING = 18;
                SMALL_ROW_SPACING_NUMBERS = 26;
                WIDTH_GLOBE_EMOJI_LEFT_OFFSET = 63;
                BIG_KEY_BUTTON_SIDE_OFFSET = 5;
                alphabet = alphabetNB;
                numbers = numbersNB;
                numbersCap = numbersCapNB;
            break;
            case 'es':
                STANDARD_KEY_WIDTH = 32;
                STANDARD_ROW_SPACING = 9;
                STANDARD_ROW_SPACING_NUMBERS = 9;
                SMALL_ROW_SPACING = 25;
                SMALL_ROW_SPACING_NUMBERS = 25;
                alphabet = alphabetES;
                numbers = numbersES;
                numbersCap = numbersCapES;
            break;
            case 'zh':
                STANDARD_KEY_WIDTH = 32;
                STANDARD_ROW_SPACING = 9;
                STANDARD_ROW_SPACING_NUMBERS = 9;
                SMALL_ROW_SPACING = 25;
                SMALL_ROW_SPACING_NUMBERS = 18;
                alphabet = alphabetZH;
                numbers = numbersZH;
                numbersCap = numbersCapZH;
            break;
        
            default:
                break;
        }
        keyMaker.loadKeyset();
    }
    function languageAndKeys(){
        var widthOfScreen = screen.width;
        switch (widthOfScreen) {
            case 414:
                iPXSMax();
            break;
            case 375:
                iPX();
            break;
        }
    }

    function initExternalMethods() {
        var externalMethods = {};
        externalMethods.languageAndKeys = function() {
            languageAndKeys();
        };
        return externalMethods;
    }
    window.setLanguage = initExternalMethods();
}(window, document));
