(function() {
    var gridMaker = function(obj) {
        function createGridObject(amountOfItems, widthOfItem, widthOfHolder, itemGapLeft, itemGapTop, topMargin, leftOffset){
            var perItems = [],
                topValue = 0,
                leftValue = 0;
            for (var i = 0; i < amountOfItems; i++) {
                perItems.push({
                    top: topValue + topMargin,
                    left:leftValue
                });
                leftValue += widthOfItem + itemGapLeft
            }
            return perItems;
        }
        if(obj){
            return createGridObject(obj.itemCount, obj.itemWidth, obj.holderWidth, obj.leftGap, obj.topGap, obj.topOffset, obj.leftOffset);
        }
    }
    window.gridMaker = gridMaker;
}());