function laetusKeyPlaneDidChange(state){
}
/*
    Keyboard numbers
    - Safari

    Capitol
    7153 (XSMax )
    7128 (iPX)

    Lowercase
    7155 (XSMax )
    7130 (iPX )

    Punctuation
    621 (iPX )
    647 (XSMax )

    Alternate
    622 (iPX )
    648 (XSMax )

    Email:
    13109 (iPX Cap)
    13111 (iPX Lower)
    824
    825


    - Discord
    Capitol
    35447 (iPX)
    35546 (XSMax)

    Lowercase
    35449 (iPX)
    35548 (XSMAX)

    388 (iPX)
    389 (XSMax)

    - Cydia
    39594 (ipx Capitol)
    39693 (XSMax Capitol)

    39596 (ipx Lower)
    39695 (XSMax Lower)
    
    1329 (ipx)
    1330 (ipx)
    1357 (xsmax)
    1358 (xsmax)

*/
function laetusRawKeyPlaneDidChange(s){
    //document.getElementById('debug').innerHTML = s;
    changesForMoreKeyboards();
    var keyPlane = s.split('-');
    numberType = Number(s.split('_')[0]);
    var lastItem = keyPlane[keyPlane.length-1];

    if(testing){
        document.getElementById('debug').innerHTML += numberType + "--" +  s + "LASTITEM: " + lastItem;
    }
    
    switch (lastItem) {
        case 'Punctuation':
            keys = numbers;
            if(numberType === 621 || numberType === 647){
                keys = numbersPeriod;
            }
            if(numberType === 1329 || numberType === 1357){
                keys = numberCydiaAddSource;
            }
            if(numberType === 824 || numberType === 855){
                keys = numberEmail;
            }
        break;
        case 'Alternate':
            keys = numbersCap;
            if(numberType === 622 || numberType === 648){
                keys = numbersCapPeriod;
            }
            if(numberType === 1330 || numberType === 1358){
                keys = numberCapCydiaAddSource;
            }
            if(numberType === 825 || numberType === 856){
                keys = numberEmailCap;
            }
        break;
        case 'Display':
            keys = alphabet;
            if(numberType === 7130 || numberType === 7155){
                keys = alphabetPeriod;
            }
            if(numberType === 35449 || numberType === 35548){
                keys = alphabetDiscord;
            }
            if(numberType === 39596 || numberType === 39695){
                keys = alphabetCydiaAddSource;
            }
            if(numberType === 13111 || numberType === 13145){
                keys = alphabetSafariEmail;
            }
            IS_UPPERCASE = false;
        break;
        case 'Letters':
            keys = alphabet;
            if(numberType === 7128 || numberType === 7153){
                keys = alphabetPeriod;
            }
            if(numberType === 35447 || numberType === 35546){
                keys = alphabetDiscord;
            }
            if(numberType === 39594 || numberType === 39693){
                keys = alphabetCydiaAddSource;
            }
            if(numberType === 13109 || numberType === 13143){
                keys = alphabetSafariEmail;
            }
            IS_UPPERCASE = true;
        break;
        case 'Pad_Default':
            keys = keypad;
            if(numberType === 25686){
                keys = keypad;
            }
            if(numberType === 25781){
                keys = keypadTel;
            }
            if(numberType === 25727){
                keys = keypadTelDecimal;
            }
        break;
        case 'Pad_Alternate':
            keys = keypadTelALT;
            if(numberType === 25782){
                keys = keypadTelALT;
            }
        break;
        case 'Picker':
            keyMaker.clearKeyboard();
            return;
        break;
        case 'Keyboard_Letters':
            keys = emoji;
        break;
    }
    CURRENT_PLANE = lastItem;
    keyMaker.loadKeyset();
}

function laetusDidTouchDown(x, y){
    var element = document.elementFromPoint(x, y);
    if(element){
        animate.animateElement(element, x, y);
    }
}

function laetusEnabledLanguages(languages){
    AMOUNT_OF_KEYBOARDS = languages.length;
}

function laetusCurrentLanguage(language){
    var lang = language.split('_')[0];
    // document.getElementById('debug').innerHTML = lang;
    CURRENT_LANGUAGE = lang;
    setLanguage.languageAndKeys();
}

function laetusDictationViewWillShow(){
    keys = dictation;
    keyMaker.loadKeyset();
}

function laetusDictationViewWillHide(){
    
}

//Testing ONLY
document.body.addEventListener('touchstart', function(e){
    laetusDidTouchDown(e.touches[0].clientX, e.touches[0].clientY);
});

