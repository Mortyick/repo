(function(window, doc) {
    var bubble = doc.getElementById('bubble');
    var bubble2 = doc.getElementById('bubble2');
    var bubbleused = null;

    function animateElement(element, x, y){
        if(bubbleused === 'bubble'){
            bubble2.classList.add('bubbleAni');
            bubble2.style.left = x-10 + "px";
            bubble2.style.top = y-10 + "px";
            bubbleused = 'bubble2';
            setTimeout(function(){
                bubble2.classList.remove('bubbleAni');
            },400);
        }else{
            bubble.classList.add('bubbleAni');
            bubble.style.left = x-10 + "px";
            bubble.style.top = y-10 + "px";
            bubbleused = 'bubble';
            setTimeout(function(){
                bubble.classList.remove('bubbleAni');
            },400);
        }
        if(element.className === 'keyContainer'){
            var children = element.children;
            if(children[0].className === 'keyOutline'){
                element.classList.add('keyAni');
                children[0].classList.add('keyOutlineAnimated');
                children[1].classList.add('keyBGDark');
                children[2].classList.add('keyTextGradient');
                setTimeout(function(){
                    element.classList.remove('keyAni');
                    children[0].classList.remove('keyOutlineAnimated');
                    children[1].classList.remove('keyBGDark');
                    children[2].classList.remove('keyTextGradient');
                },300);
            }
        }
    }

    function initExternalMethods() {
        var externalMethods = {};
        externalMethods.animateElement = function(element, x, y) {
            animateElement(element, x, y);
        };
        return externalMethods;
    }
    window.animate = initExternalMethods();
}(window, document));
