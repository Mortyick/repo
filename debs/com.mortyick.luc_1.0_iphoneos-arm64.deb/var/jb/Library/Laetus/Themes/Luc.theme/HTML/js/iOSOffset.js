(function(window, doc) {
    function iPXGrid(grid, id){
        if(grid.length === 10){
            if(id === 0){
                grid[id].left = grid[id].left -3.5;
            }
            if(id === 1){
                grid[id].left = grid[id].left -3;
            }
            if(id === 2){
                grid[id].left = grid[id].left -2;
            }
            if(id === 3){
                grid[id].left = grid[id].left -1;
            }
            if(id === 4){
                grid[id].left = grid[id].left -1.2;
            }
            if(id === 5){
                grid[id].left = grid[id].left -1.1;
            }
            if(id === 6){
                grid[id].left = grid[id].left + -0.22;
            }
            if(id === 7){
                grid[id].left = grid[id].left + 1;
            }
            if(id === 8){
                grid[id].left = grid[id].left + 0.6;
            }
            if(id === 9){
                grid[id].left = grid[id].left +1.5;
            }
        }
        if(grid.length === 9){
            if(id === 0){
                grid[id].left = grid[id].left -3.3;
            }
            if(id === 1){
                grid[id].left = grid[id].left -3;
            }
            if(id === 2){
                grid[id].left = grid[id].left -1.6;
            }
            if(id === 3){
                grid[id].left = grid[id].left -1.8;
            }
            if(id === 4){
                grid[id].left = grid[id].left -0.7;
            }
            if(id === 5){
                grid[id].left = grid[id].left +0.2;
            }
            if(id === 6){
                grid[id].left = grid[id].left + 0.4;
            }
            if(id === 7){
                grid[id].left = grid[id].left + 0.1;
            }
            if(id === 8){
                grid[id].left = grid[id].left + 0.6;
            }
        }
        if(grid.length === 7){
            if(id === 0){
                grid[id].left = grid[id].left -3.0;
            }
            if(id === 1){
                grid[id].left = grid[id].left -1.6;
            }
            if(id === 2){
                grid[id].left = grid[id].left -1.7;
            }
            if(id === 3){
                grid[id].left = grid[id].left -0.5;
            }
            if(id === 4){
                grid[id].left = grid[id].left + 0.4;
            }
            if(id === 5){
                grid[id].left = grid[id].left +0.2;
            }
            if(id === 6){
                grid[id].left = grid[id].left + 0.5;
            }
        }
        return grid;
    }

    function iPXSGrid(grid, id){
        if(grid.length === 10){
            if(id === 0){
                grid[id].left = grid[id].left -1;
            }
            if(id === 1){
                grid[id].left = grid[id].left -0.6;
            }
            if(id === 2){
                grid[id].left = grid[id].left -0.5;
            }
            if(id === 3){
                grid[id].left = grid[id].left -1;
            }
            if(id === 4){
                grid[id].left = grid[id].left -1.2;
            }
            if(id === 5){
                grid[id].left = grid[id].left -0.8;
            }
            if(id === 6){
                grid[id].left = grid[id].left -0.6;
            }
            if(id === 7){
                grid[id].left = grid[id].left -0.6;
            }
            if(id === 8){
                grid[id].left = grid[id].left - 0.8;
            }
            if(id === 9){
                grid[id].left = grid[id].left + 0;
            }
        }
        if(grid.length === 9){
            if(id === 0){
                grid[id].left = grid[id].left -0.8;
            }
            if(id === 1){
                grid[id].left = grid[id].left -0.8;
            }
            if(id === 2){
                grid[id].left = grid[id].left -0;
            }
            if(id === 3){
                grid[id].left = grid[id].left -0.3;
            }
            if(id === 4){
                grid[id].left = grid[id].left + 0.2;
            }
            if(id === 5){
                grid[id].left = grid[id].left - 0.2;
            }
            if(id === 6){
                grid[id].left = grid[id].left + 0;
            }
            if(id === 7){
                grid[id].left = grid[id].left - 0;
            }
            if(id === 8){
                grid[id].left = grid[id].left + 0.3;
            }
        }
        if(grid.length === 7){
            if(id === 0){
                grid[id].left = grid[id].left - 0;
            }
            if(id === 1){
                grid[id].left = grid[id].left -0.5;
            }
            if(id === 2){
                grid[id].left = grid[id].left - 0.5;
            }
            if(id === 3){
                grid[id].left = grid[id].left -0.2;
            }
            if(id === 4){
                grid[id].left = grid[id].left + 0;
            }
            if(id === 5){
                grid[id].left = grid[id].left +0;
            }
            if(id === 6){
                grid[id].left = grid[id].left + 0;
            }
        }
        return grid;
    }
    function fixOffset(grid){
        grid.forEach(function(key, id){
            if(screen.width === 375 && screen.height === 812){
                grid = iPXGrid(grid, id);
            }else if(screen.width === 414 && screen.height === 896){
                grid = iPXSGrid(grid, id);
            }
        });
        return grid;
    }

    function initExternalMethods() {
        var externalMethods = {};
        externalMethods.fixOffset = function(grid) {
            try{
                return fixOffset(grid);
            }catch(err){
                document.getElementById('debug').innerHTML = err + "iOSOffset";
                return grid;
            }
        };
        return externalMethods;
    }
    window.iOSOffset = initExternalMethods();
}(window, document));
