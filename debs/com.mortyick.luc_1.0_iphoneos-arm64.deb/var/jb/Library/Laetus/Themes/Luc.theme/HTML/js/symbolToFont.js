(function(window, doc) {
    function getIconLetter(letter){
        var keyText = "";
        switch (letter){
        case "clock": 
            keyText = "J";
        break;
        case "face": 
            keyText = "I";
        break;
        case "animal": 
            keyText = "H";
        break;
        case "food": 
            keyText = "G";
        break;
        case "sports": 
            keyText = "F";
        break;
        case "city": 
            keyText = "E";
        break;
        case "symbols": 
            keyText = "D";
        break;
        case "random": 
            keyText = "B";
        break;
        case "flags": 
            keyText = "C";
        break;
        case "<": 
            keyText = "A";
        break;
        case "^": 
            keyText = "L"; //orK
        break;
        case "dictation": 
            keyText = "M";
        break;
        case "emojiface": 
            keyText = "I";
        break;
        case "dictationfull": 
            keyText = "P";
        break;
        case "emojifull": 
            keyText = "O"; //or I
        break;
        case "keyboard": 
            keyText = "N";
        break;
        case "globe": 
            keyText = "Q";
        break;
        case "shiftfull": 
            keyText = "K";
        break;
        case "space": 
            keyText = "R";
        break;
        case "return": 
            keyText = "S";
        break;
        case "numbers": 
            keyText = "T";
        break;
        case "letters": 
            keyText = "U";
        break;

        }
        return keyText;
    }

    function initExternalMethods() {
        var externalMethods = {};
        externalMethods.getIconLetter = function(letter) {
            return getIconLetter(letter);
        };
        return externalMethods;
    }
    window.symbolToFont = initExternalMethods();
}(window, document));
