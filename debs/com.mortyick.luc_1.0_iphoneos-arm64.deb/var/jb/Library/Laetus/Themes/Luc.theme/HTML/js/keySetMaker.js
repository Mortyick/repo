(function(window, doc) {
    function makeKeysFromObject(obj){
        var keySet = {};
        Object.keys(obj).forEach(function(key) {
            var div = doc.createElement('div');
            if (obj[key].left) {
                div.style.left = obj[key].left;
            }
            if (obj[key].top) {
                div.style.top = obj[key].top;
            }
            if (obj[key].class) {
                div.className = obj[key].class;
            }
            if (obj[key].title) {
                div.title = obj[key].title;
            }
            if (obj[key].fonts) {
                div.style.fontFamily = obj[key].fonts;
            }
            if (obj[key].fontSize) {
                div.style.fontSize = obj[key].fontSize;
            }
            if (obj[key].innerHTML) {
                div.innerHTML = obj[key].innerHTML;
                if(HIDE_LETTERS){
                    div.innerHTML = "";
                }
            }
            if (obj[key].lineHeight) {
                div.style.lineHeight = obj[key].lineHeight;
            }
            if (key === 'keyOutline') {
                div.style.width = STANDARD_KEY_WIDTH;
                if (obj[key].width) { //if width set manually
                    div.style.width = obj[key].width;
                }
                div.style.height = STANDARD_KEY_HEIGHT;
                div.style.lineHeight = STANDARD_KEY_HEIGHT + 'px';
                if (obj[key].height) {
                    div.style.height = obj[key].height + "px";
                    div.style.lineHeight = obj[key].height + 'px';
                }
                if (obj[key].lineHeight) {
                    div.style.lineHeight = obj[key].lineHeight + "px";
                }
            } else {
                div.style.width = STANDARD_KEY_WIDTH;
                if (obj[key].width) { //if width set manually
                    div.style.width = obj[key].width;
                }
                div.style.height = STANDARD_KEY_HEIGHT;
                div.style.lineHeight = STANDARD_KEY_HEIGHT + 'px';
                if (obj[key].height) {
                    div.style.height = obj[key].height + "px";
                    div.style.lineHeight = obj[key].height + 'px';
                }
                if (obj[key].lineHeight) {
                    div.style.lineHeight = obj[key].lineHeight + "px";
                }
            }
            keySet[key] = div;
        });
        keySet.keyContainer.appendChild(keySet.keyOutline);
        keySet.keyContainer.appendChild(keySet.keyBG);
        keySet.keyContainer.appendChild(keySet.keyText);
        if(keySet.extra){
            keySet.keyContainer.appendChild(keySet.extra);
        }
        return keySet.keyContainer;
    }

    function initExternalMethods() {
        var externalMethods = {};
        externalMethods.makeKeys = function(keyObject) {
            return makeKeysFromObject(keyObject);
        };
        return externalMethods;
    }
    window.keySetMaker = initExternalMethods();
}(window, document));
