/* users can use this to have more symbols */
var moreSymbols = true;
var keys = alphabet;
var keyboardDiv = document.getElementById('keyboard');

var keyMaker = {
    clearKeyboard: function(){
        keyboardDiv.innerHTML = "";
    },
    createRow: function(rowWidth){
        var keysRow = document.createElement('div');
        keysRow.className = "row";
        keysRow.style.width = rowWidth;
        keysRow.style.height = STANDARD_KEY_HEIGHT;
        rowLeft = screen.width / 2 - parseInt(keysRow.style.width, 10) / 2;
        keysRow.style.left = rowLeft;
        return keysRow;
    },
    setupRowKeys: function(obj){
        var width = STANDARD_KEY_WIDTH;
        var keyGap = STANDARD_ROW_SPACING;
        if(CURRENT_PLANE === 'Punctuation' || CURRENT_PLANE === 'Alternate'){
            keyGap = STANDARD_ROW_SPACING_NUMBERS;
            if(obj.keys.length <= 6){
                keyGap = SMALL_ROW_SPACING_NUMBERS;
            }

            //Cydia add Source
            if(obj.keys.length === 8){
                keyGap = 13;
            }
            if(obj.keys.length === 4){
                keyGap = 35;
            }
            //Cydia add Source

        }else{
            keyGap = STANDARD_ROW_SPACING;
            if(obj.keys.length <= 5){
                keyGap = SMALL_ROW_SPACING;
            }
        }
        var grid = gridMaker({
            itemCount: obj.keys.length,
            itemWidth: width,
            holderWidth: screen.width,
            leftGap: keyGap,
            topGap: 0,
            topOffset: obj.y
        }),
        rowWidth = grid[grid.length - 1].left + STANDARD_KEY_WIDTH, //minus one because of outline
        keysRow = this.createRow(rowWidth),
        key = null, i, keyInnerHTML = "";
        keyboardDiv.appendChild(keysRow);
        grid = iOSOffset.fixOffset(grid);
        for (i = 0; i < obj.keys.length; i++) {
            keyInnerHTML = obj.keys[i];
            if(IS_UPPERCASE){
                keyInnerHTML = obj.keys[i].toUpperCase();
            }
            keysRow.style.top = grid[i].top + 'px';
            key = keySetMaker.makeKeys({
                keyContainer: {
                    class: 'keyContainer',
                    left: grid[i].left + "px",
                },
                keyOutline: {
                    class: 'keyOutline'
                },
                keyBG: {
                    class: 'keyBG regularRow'
                },
                keyText: {
                    class: 'keyText regularRowText',
                    innerHTML: keyInnerHTML,
                    title: obj.keys[i]
                }
            });
            keysRow.appendChild(key);
        }
    },
    setupShiftBackspace: function(obj){
        var i, 
        leftVal = "8", 
        symbol = "<",
        font = null;
        width = null;
        for (i = 0; i < obj.keys.length; i++) {
            font=null;
            if (obj.keys[i] === 'shift') {
                leftVal = BIG_KEY_BUTTON_SIDE_OFFSET;
                symbol = symbolToFont.getIconLetter("^");
                font = 'emoji';
                width = SHIFT_BACKSPACE_WIDTH;
            }else if(obj.keys[i] === 'shiftfull'){
                leftVal = BIG_KEY_BUTTON_SIDE_OFFSET;
                symbol = symbolToFont.getIconLetter('shiftfull');
                width = SHIFT_BACKSPACE_WIDTH;
                font = 'emoji';
            } else {
                width = SHIFT_BACKSPACE_WIDTH;
                leftVal = screen.width - width - BIG_KEY_BUTTON_SIDE_OFFSET;
                symbol = symbolToFont.getIconLetter("<");
                font = 'emoji';
            }
            key = keySetMaker.makeKeys({
                keyContainer: {
                    class: 'keyContainer',
                    left: leftVal + "px",
                    top: obj.y + "px",
                    width: width
                },
                keyOutline: {
                    class: 'keyOutline',
                    width: width
                },
                keyBG: {
                    class: 'keyBG sideKeys',
                    width: width
                },
                keyText: {
                    class: 'keyText sideKeysText',
                    innerHTML: symbol,
                    title: symbol,
                    fonts: font,
                    width: width
                }
            });
            keyboardDiv.appendChild(key);
        }
    },
    setupABCSpaceReturn: function(obj){
        var i, 
        leftVal = "8", 
        symbol = "<",
        width = STANDARD_KEY_WIDTH, //manually changing the width
        containsEmoji = false,
        fontSize = false,
        font = false,
        sideClass = '',
        lineHeight = null,
        notIPX = false;
        for (i = 0; i < obj.keys.length; i++) {
            notIPX = false;
            lineHeight = null;
            sideClass = '';
            textClass = '';
            fontSize = false;
            font = false;
            if(obj.keys.includes('emoji')){
                containsEmoji = true;
            }
            if(obj.keys.length > 4){
                notIPX = true;
            }
            if (obj.keys[i] === '123' || obj.keys[i] === 'ABC') {
                leftVal = BIG_KEY_BUTTON_SIDE_OFFSET;
                symbol = "123";
                lineHeight = 45;
                if (obj.keys[i] === 'ABC') {
                    symbol = "ABC";
                    fontSize = 15;
                }else{
                    fontSize = 15;
                }
                width = KB_SWITCH_WIDTH;
                if(containsEmoji){
                    width = STANDARD_KEY_WIDTH + 5;
                    if(notIPX){
                        width = NONIPX_NUM_WIDTH;
                        leftVal = NONIPX_NUM_LEFT;
                    }
                    fontSize = 10;
                }
                sideClass = 'sideKeys keyABC';
                textClass = 'keyABCText';
                if(moreSymbols){
                    if(obj.keys[i] === '123'){
                        font = 'emoji';
                        fontSize = 12;
                        lineHeight = 40;
                        symbol = symbolToFont.getIconLetter('numbers');
                    }else{
                        font = 'emoji';
                        fontSize = 12;
                        lineHeight = 40;
                        symbol = symbolToFont.getIconLetter('letters');
                    }
                }
            }else if (obj.keys[i] === 'space') {
                symbol = 'space';
                width = SPACEBAR_WIDTH;
                leftVal = screen.width/2 - width/2;

                //Offsets

                //iPX Letter
                if(numberType === 7130 || numberType === 7128){
                    width =  SPACEBAR_WIDTH_PERIOD;
                    leftVal = BIG_KEY_BUTTON_SIDE_OFFSET + SHIFT_BACKSPACE_WIDTH + 55;
                }
                //iPX Number
                if(numberType === 621 || numberType === 622){
                    width =  SPACEBAR_WIDTH_PERIOD;
                    leftVal = BIG_KEY_BUTTON_SIDE_OFFSET + SHIFT_BACKSPACE_WIDTH + 55;
                }

                //XSMax Letter
                if(numberType === 7155 || numberType === 7153){
                    leftVal = leftVal-5;
                }
                //XSMax Number
                if(numberType === 647 || numberType === 648){
                    leftVal = leftVal-5;
                }
                sideClass = 'spacebar';
                textClass = 'spacebarText';
                if(moreSymbols){
                    font = 'emoji';
                    symbol = symbolToFont.getIconLetter('space');
                    lineHeight = 60;
                }
                if(notIPX){
                    width = NONIPX_SPACEBAR_WIDTH;
                    leftVal = NONIPX_SPACEBAR_LEFT;
                }
            }else if (obj.keys[i] === 'espacio') {
                symbol = 'espacio';
                width = SPACEBAR_WIDTH;
                leftVal = screen.width/2 - width/2;
                sideClass = 'spacebar';
                textClass = 'spacebarText';
                if(moreSymbols){
                    font = 'emoji';
                    symbol = symbolToFont.getIconLetter('space');
                    lineHeight = 60;
                }
                if(notIPX){
                    width = NONIPX_SPACEBAR_WIDTH;
                    leftVal = NONIPX_SPACEBAR_LEFT;
                }
            }else if (obj.keys[i] === 'return') {
                width = RETURN_WIDTH;

                //Offsets

                //iPX Letter
                if(numberType === 7130 || numberType === 7128){
                    width = RETURN_WIDTH_PERIOD;
                }
                //iPX Number
                if(numberType === 621 || numberType === 622){
                    width = RETURN_WIDTH_PERIOD;
                }

                //XSMax Letter
                if(numberType === 7155 || numberType === 7153){
                    width = RETURN_WIDTH_PERIOD - 8;
                }
                //XSMax Number
                if(numberType === 647 || numberType === 648){
                    width = RETURN_WIDTH_PERIOD - 8;
                }

                leftVal = screen.width - width - BIG_KEY_BUTTON_SIDE_OFFSET;
                symbol = "return";
                sideClass = 'sideKeys keyReturn';
                textClass = 'keyReturnText';
                fontSize = 15;
                lineHeight = 43;
                if(moreSymbols){
                    font = 'emoji';
                    lineHeight = 40;
                    symbol = symbolToFont.getIconLetter('return');
                }
                if(notIPX){
                    leftVal = NONIPX_RET_LEFT;
                    width = NONIPX_RET_WIDTH;
                }
            }else if (obj.keys[i] === 'intro') {
                width = RETURN_WIDTH;
                leftVal = screen.width - width - BIG_KEY_BUTTON_SIDE_OFFSET;
                symbol = "intro";
                sideClass = 'sideKeys keyReturn';
                textClass = 'keyReturnText';
                fontSize = 15;
                lineHeight = 43;
                if(moreSymbols){
                    font = 'emoji';
                    lineHeight = 40;
                    symbol = symbolToFont.getIconLetter('return');
                }
            }else if (obj.keys[i] === 'emoji') {
                width = STANDARD_KEY_WIDTH;
                leftVal = WIDTH_GLOBE_EMOJI_LEFT_OFFSET;
                if(notIPX){
                    width = NONIPX_EMOJI_WIDTH;
                    leftVal = NONIPX_EMOJI_LEFT;
                }
                symbol = symbolToFont.getIconLetter('emojifull');
                font = 'emoji';
                sideClass = 'sideKeys keyEmoji';
                textClass = 'keyEmojiText';
            }else if (obj.keys[i] === 'globe') { //should only show on nonipx
                width = STANDARD_KEY_WIDTH;
                leftVal = WIDTH_GLOBE_EMOJI_LEFT_OFFSET;
                if(notIPX){
                    width = NONIPX_GLOB_WIDTH;
                    leftVal = NONIPX_GLOB_LEFT;
                }
                symbol = symbolToFont.getIconLetter('globe');
                font = 'emoji';
                sideClass = 'sideKeys keyEmoji';
                textClass = 'keyEmojiText';
            }else if (obj.keys[i] === 'dictationfull'){
                width = STANDARD_KEY_WIDTH;
                leftVal = WIDTH_GLOBE_EMOJI_LEFT_OFFSET;
                if(notIPX){
                    width = NONIPX_DIC_WIDTH;
                    leftVal = NONIPX_DIC_LEFT;
                }
                symbol = symbolToFont.getIconLetter('dictationfull');
                font = 'emoji';
                sideClass = 'sideKeys keyDictation';
                textClass = 'keyEmojiText';
            }else if (obj.keys[i] === '.') {
                symbol = '.';
                width = STANDARD_KEY_WIDTH;
                leftVal = screen.width - RETURN_WIDTH_PERIOD - width - 10;
                //Offsets

                //XSMax Letter
                if(numberType === 7155 || numberType === 7153){
                    leftVal = screen.width - RETURN_WIDTH_PERIOD - width - 14;
                }
                //XSMax Number
                if(numberType === 647 || numberType === 648){
                    leftVal = screen.width - RETURN_WIDTH_PERIOD - width - 14;
                }

                sideClass = 'periodtext';
                textClass = 'periodText';
                lineHeight = 40;
                if(moreSymbols){
                    font = 'emoji';
                    symbol = '.';
                    lineHeight = 40;
                }
                if(notIPX){
                    width = NONIPX_SPACEBAR_WIDTH;
                    leftVal = NONIPX_SPACEBAR_LEFT;
                }
            }else if (obj.keys[i] === '#') {
                symbol = '#';
                width = STANDARD_KEY_WIDTH;
                leftVal = screen.width - width - BIG_KEY_BUTTON_SIDE_OFFSET;
                sideClass = 'poundtext';
                textClass = 'poundText';
                lineHeight = 40;
                if(moreSymbols){
                    font = 'emoji';
                    symbol = '#';
                    lineHeight = 40;
                }
                if(notIPX){
                    width = NONIPX_SPACEBAR_WIDTH;
                    leftVal = NONIPX_SPACEBAR_LEFT;
                }
            }else if (obj.keys[i] === '@') {
                symbol = '@';
                width = STANDARD_KEY_WIDTH;
                leftVal = screen.width - width - BIG_KEY_BUTTON_SIDE_OFFSET - STANDARD_KEY_WIDTH - 15;
                sideClass = 'attext';
                textClass = 'atText';
                lineHeight = 40;

                //Offset

                //XSMax Letter moving @ over
                if(numberType === 35546 || numberType === 35548){
                    leftVal = leftVal - 10;
                }
                
                if(moreSymbols){
                    font = 'emoji';
                    symbol = '@';
                    lineHeight = 40;
                }
                if(notIPX){
                    width = NONIPX_SPACEBAR_WIDTH;
                    leftVal = NONIPX_SPACEBAR_LEFT;
                }
            }else if (obj.keys[i] === '/') {
                symbol = '.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<small>/</small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<small style="font-size:15px;">.com</small>';
                width = SPACEBAR_WIDTH;
                leftVal = screen.width/2 - width/2;
                sideClass = 'attext';
                textClass = 'atText';
                lineHeight = 32;
                if(moreSymbols){
                    font = 'emoji';
                    symbol = '.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<small>/</small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<small style="font-size:15px;">.com</small>';
                    lineHeight = 32;
                }
                if(notIPX){
                    width = NONIPX_SPACEBAR_WIDTH;
                    leftVal = NONIPX_SPACEBAR_LEFT;
                }
                //Offsets

                //XSMax Letter
                if(numberType === 7155 || numberType === 7153){
                    symbol = '.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<small>/</small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<small style="font-size:15px;">.com</small>';
                }
                //XSMax Number
                if(numberType === 647 || numberType === 648){
                    symbol = '.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<small>/</small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<small style="font-size:15px;">.com</small>';
                }
            }else if (obj.keys[i] === 'email') {
                symbol = '<small style="font-size:9px">space</small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<small>@</small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<small style="font-size:15px;">.</small>';
                width = SPACEBAR_WIDTH;
                leftVal = screen.width/2 - width/2;
                sideClass = 'attext';
                textClass = 'atText';
                lineHeight = 32;
                if(moreSymbols){
                    font = 'emoji';
                    symbol = '<small style="font-size:9px">space</small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<small>@</small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<small style="font-size:15px;">.</small>';
                    lineHeight = 32;
                }
                if(notIPX){
                    width = NONIPX_SPACEBAR_WIDTH;
                    leftVal = NONIPX_SPACEBAR_LEFT;
                }
                //Offsets

                //XSMax Letter
                if(numberType === 7155 || numberType === 7153){
                    symbol = '<small style="font-size:9px">space</small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<small>@</small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<small style="font-size:15px;">.</small>';
                }
                //XSMax Number
                if(numberType === 647 || numberType === 648){
                    symbol = '<small style="font-size:9px">space</small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<small>@</small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<small style="font-size:15px;">.</small>';
                }
            }
            key = keySetMaker.makeKeys({
                keyContainer: {
                    class: 'keyContainer',
                    left: leftVal + "px",
                    top: obj.y + "px",
                    width: width
                },
                keyOutline: {
                    class: 'keyOutline',
                    width: width
                },
                keyBG: {
                    class: 'keyBG ' + sideClass,
                    width: width
                },
                keyText: {
                    class: 'keyText ' + textClass,
                    innerHTML: symbol,
                    title: symbol,
                    width: width,
                    fontSize: fontSize,
                    fonts: font,
                    lineHeight: lineHeight
                }
            });
            keyboardDiv.appendChild(key);
        }      
    },
    setupEmojiDictation: function(obj){
        if(HIDE_EMOJI_KEYS){
            return;
        }
        var i, 
        leftVal = '8',
        symbol = '<',
        width = STANDARD_KEY_WIDTH,
        font = null,
        sideClass = '',
        textClass = '';
        for (i = 0; i < obj.keys.length; i++) {
            font = null;
            if (obj.keys[i] === 'emoji') {
                leftVal = BIG_KEY_BUTTON_SIDE_OFFSET;
                symbol = symbolToFont.getIconLetter('emojiface');
                width = EMOJI_BUTTON_WIDTH;
                font = 'emoji';
                sideClass = 'sideKeys keyEmoji';
                textClass = 'keyEmojiText';
            }else if (obj.keys[i] === 'emojifull') {
                leftVal = BIG_KEY_BUTTON_SIDE_OFFSET;
                symbol = symbolToFont.getIconLetter('emojifull');
                width = EMOJI_BUTTON_WIDTH;
                font = 'emoji';
                sideClass = 'sideKeys keyEmoji';
                textClass = 'keyEmojiText';
            }else if (obj.keys[i] === 'globe') {
                leftVal = BIG_KEY_BUTTON_SIDE_OFFSET;
                symbol = symbolToFont.getIconLetter('globe');
                width = GLOBE_BUTTON_WIDTH;
                font = 'emoji';
                sideClass = 'sideKeys keyGlobe';
                textClass = 'keyGlobeText';
            } else if (obj.keys[i] === 'dictation') {
                width = DICTATION_BUTTON_WIDTH;
                leftVal = screen.width - width - BIG_KEY_BUTTON_SIDE_OFFSET;
                symbol = symbolToFont.getIconLetter('dictation');
                font = 'emoji';
                sideClass = 'sideKeys keyDictation';
            }else if (obj.keys[i] === 'dictationfull') {
                width = DICTATION_BUTTON_WIDTH;
                leftVal = screen.width - width - BIG_KEY_BUTTON_SIDE_OFFSET;
                symbol = symbolToFont.getIconLetter('dictationfull');
                font = 'emoji';
                sideClass = 'sideKeys keyDictation';
                textClass = 'keyDictationText';
            }
            key = keySetMaker.makeKeys({
                keyContainer: {
                    class: 'keyContainer',
                    left: leftVal + "px",
                    top: obj.y + "px",
                    width: width
                },
                keyOutline: {
                    class: 'keyOutline',
                    width: width
                },
                keyBG: {
                    class: 'keyBG ' + sideClass,
                    width: width
                },
                keyText: {
                    class: 'keyText ' + textClass,
                    innerHTML: (HIDE_EMOJI_KEYS_LETTERS) ? "" : symbol,
                    title: symbol,
                    width: width,
                    fonts: 'emoji'
                }
            });
            keyboardDiv.appendChild(key);
        }
    },
    setupDictation: function(obj){
        var i, 
        leftVal = '8',
        symbol = symbolToFont.getIconLetter('keyboard'),
        width = STANDARD_KEY_WIDTH*2;
        for (i = 0; i < obj.keys.length; i++) {
            if (obj.keys[i] === 'kb') {
                if(screen.width === 320){
                    width = 150;
                }
                leftVal = screen.width/2 - width/2;
            }
            key = keySetMaker.makeKeys({
                keyContainer: {
                    class: 'keyContainer',
                    left: leftVal + "px",
                    top: obj.y + "px",
                    width: width
                },
                keyOutline: {
                    class: 'keyOutline',
                    width: width
                },
                keyBG: {
                    class: 'keyBG',
                    width: width
                },
                keyText: {
                    class: 'keyText',
                    innerHTML: 'symbol',
                    title: symbol,
                    width: width,
                    fonts: 'emoji'
                }
            });
            keyboardDiv.appendChild(key);
        }
    },
    setupEmojiPickerRow: function(obj){
        if(HIDE_EMOJI_KB_ROW_BG){
            return;
        }
        var width = EMOJI_SELECTOR_WIDTH,
            height = EMOJI_SELECTOR_WIDTH;
        var spacing = EMOJI_SELECTOR_SPACING;
        var grid = gridMaker({
            itemCount: obj.keys.length,
            itemWidth: width,
            holderWidth: screen.width,
            leftGap: spacing,
            topGap: 0,
            topOffset: obj.y
        }),
        rowWidth = grid[grid.length - 1].left + width,
        keysRow = this.createRow(rowWidth),
        key = null, i;
        keyboardDiv.appendChild(keysRow);
        for (i = 0; i < obj.keys.length; i++) {
            keysRow.style.top = grid[i].top + 'px';
            keyText = symbolToFont.getIconLetter(obj.keys[i]);
            key = keySetMaker.makeKeys({
                keyContainer: {
                    class: 'keyContainer',
                    height: height,
                    left: grid[i].left+ "px",
                    width:width
                },
                keyOutline: {
                    height: height,
                    class: 'keyOutline',
                    width:width
                },
                keyBG: {
                    height: height,
                    class: 'keyBG emojiRow',
                    width:width
                },
                keyText: {
                    height: height,
                    class: 'keyText',
                    innerHTML: keyText,
                    title: keyText,
                    fonts: 'emoji',
                    width:width
                }
            });
            keysRow.appendChild(key);
        }
    },
    setupEmojiABCDictation: function(obj){
        if(HIDE_EMOJI_KB_BOTTOM_KEYS){
            return;
        }
        var i, 
        leftVal = EMOJI_BOTTOM_BUTTON_OFFSET, 
        symbol = "<",
        width = STANDARD_KEY_WIDTH, //manually changing the width
        font = null,
        sideClass = '',
        textClass = '';
        for (i = 0; i < obj.keys.length; i++) {
            font = null;
            if (obj.keys[i] === '123' || obj.keys[i] === 'ABC') {
                leftVal = EMOJI_BOTTOM_BUTTON_OFFSET;
                symbol = "123";
                if (obj.keys[i] === 'ABC') {
                    symbol = "ABC";
                }
                width = EMOJI_BOTTOM_BUTTON_WIDTH_ABC;
                sideClass = 'emojiBottom emojiABC';
                textClass = 'emojiABCText';
            }else if (obj.keys[i] === 'dictation') {
                width = EMOJI_BOTTOM_BUTTON_WIDTH_DICTATION;
                leftVal = screen.width - width - EMOJI_BOTTOM_BUTTON_OFFSET;
                symbol = symbolToFont.getIconLetter('dictation');
                font = 'emoji';
                sideClass = 'emojiBottom emojiDictation';
                textClass = 'emojiDictationText';
            }else if (obj.keys[i] === 'dictationfull') {
                width = EMOJI_BOTTOM_BUTTON_WIDTH_DICTATION;
                leftVal = screen.width - width - EMOJI_BOTTOM_BUTTON_OFFSET;
                symbol = symbolToFont.getIconLetter('dictationfull');
                font = 'emoji';
                sideClass = 'emojiBottom emojiDictation';
                textClass = 'emojiDictationText';
            }
            key = keySetMaker.makeKeys({
                keyContainer: {
                    class: 'keyContainer',
                    left: leftVal + "px",
                    top: obj.y + "px",
                    width: width
                },
                keyOutline: {
                    class: 'keyOutline',
                    width: width
                },
                keyBG: {
                    class: 'keyBG ' + sideClass,
                    width: width
                },
                keyText: {
                    class: 'keyText ' + textClass,
                    innerHTML: (HIDE_EMOJI_KEYS_LETTERS || HIDE_EMOJI_KB_KEYS_LETTERS) ? "" : symbol,
                    title: symbol,
                    width: width,
                    fonts: font
                }
            });
            keyboardDiv.appendChild(key);
        }
    },
    setupKeypad: function(obj){
        console.log(obj);
        var i, 
        offset = 30,
        leftVal = 0,
        symbol = '',
        extra = '',
        mainLineHeight = 20,
        extraLineHeight = 55,
        fontSize = 18,
        extraFontSize = 12,
        width = STANDARD_KEY_WIDTH*2;
        for (i = 0; i < obj.keys.length; i++) {
            symbol = obj.keys[i];
            extra = obj.extra[i];
            if(i === 0){
                leftVal = offset;
            }
            if(i === 1){
                leftVal = screen.width/2 - width/2;
            }
            if(i === 2){
                leftVal = screen.width - width - offset;
            }
            if(symbol === '0' || symbol === "#" || symbol === 'pause' || symbol === 'wait' || symbol === '*' || symbol === '123' || symbol === '+'){
                mainLineHeight = 35;
            }
            if(symbol === 'delete'){
                symbol = symbolToFont.getIconLetter("<");
                mainLineHeight = 40;
                font = 'emoji'
            }
            key = keySetMaker.makeKeys({
                keyContainer: {
                    class: 'keyContainer',
                    left: leftVal + "px",
                    top: obj.y + "px",
                    width: width
                },
                keyOutline: {
                    class: 'keyOutline',
                    width: width
                },
                keyBG: {
                    class: 'keyBG',
                    width: width
                },
                keyText: {
                    class: 'keyText',
                    innerHTML: symbol,
                    title: symbol,
                    width: width,
                    fonts: 'emoji',
                    fontSize: fontSize,
                    lineHeight: mainLineHeight
                },
                extra: {
                    class: 'keyTextExtra',
                    innerHTML: extra,
                    title: extra,
                    width: width,
                    fonts: 'emoji',
                    fontSize: extraFontSize,
                    lineHeight: extraLineHeight
                }
            });
            keyboardDiv.appendChild(key);
        }
    },
    loadKeyset: function(){
        this.clearKeyboard();
        
        try{
            for (var i = 0; i < keys.length; i++) {
                if(keys[i].id === 'standardKeys'){
                    this.setupRowKeys(keys[i]);
                }else if (keys[i].id === 'shiftBackspace'){
                    this.setupShiftBackspace(keys[i]);
                }else if (keys[i].id === 'abcSpaceReturn'){
                    this.setupABCSpaceReturn(keys[i]);
                }else if (keys[i].id === 'emojiDictation'){
                    this.setupEmojiDictation(keys[i]);
                }else if (keys[i].id === 'dictation'){
                    this.setupDictation(keys[i]);
                }else if (keys[i].id === 'emojiPickerRow'){
                    this.setupEmojiPickerRow(keys[i]);
                }else if (keys[i].id === 'emojiABCDictation'){
                    this.setupEmojiABCDictation(keys[i]);
                }else if(keys[i].id === 'keypadKeys'){
                    this.setupKeypad(keys[i]);
                }
            }
        }catch(err){
            document.getElementById('debug').innerHTML = err + "iOSOffset";
        }
    }
};
// keys = numbers;
keyMaker.loadKeyset();
