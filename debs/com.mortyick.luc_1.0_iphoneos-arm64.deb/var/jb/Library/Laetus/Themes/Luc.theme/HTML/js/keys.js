/* Default */
var alphabet = [
    {
        keys:['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
        y: FIRST_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['a','s','d','f','g','h','j','k','l'],
        y: SECOND_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['z','x','c','v','b','n','m'],
        y: THIRD_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['shift', 'backspace'],
        y: THIRD_ROW_Y,
        id: 'shiftBackspace'
    },
    {
        keys:['123', 'space', 'return'],
        y: FOURTH_ROW_Y,
        id: 'abcSpaceReturn'
    },
    {
        keys:['emojifull', 'dictationfull'],
        y: FIFTH_ROW_Y,
        id: 'emojiDictation'
    }
];

//usually safari and adds a period to the bottom next to spacebar
var alphabetPeriod = [
    {
        keys:['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
        y: FIRST_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['a','s','d','f','g','h','j','k','l'],
        y: SECOND_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['z','x','c','v','b','n','m'],
        y: THIRD_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['shift', 'backspace'],
        y: THIRD_ROW_Y,
        id: 'shiftBackspace'
    },
    {
        keys:['123', 'space', '.', 'return'],
        y: FOURTH_ROW_Y,
        id: 'abcSpaceReturn'
    },
    {
        keys:['emojifull', 'dictationfull'],
        y: FIFTH_ROW_Y,
        id: 'emojiDictation'
    }
];

var alphabetCydiaAddSource = [
    {
        keys:['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
        y: FIRST_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['a','s','d','f','g','h','j','k','l'],
        y: SECOND_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['z','x','c','v','b','n','m'],
        y: THIRD_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['shift', 'backspace'],
        y: THIRD_ROW_Y,
        id: 'shiftBackspace'
    },
    {
        keys:['123', '/','return'],
        y: FOURTH_ROW_Y,
        id: 'abcSpaceReturn'
    },
    {
        keys:['emojifull', 'dictationfull'],
        y: FIFTH_ROW_Y,
        id: 'emojiDictation'
    }
];

var alphabetSafariEmail = [
    {
        keys:['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
        y: FIRST_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['a','s','d','f','g','h','j','k','l'],
        y: SECOND_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['z','x','c','v','b','n','m'],
        y: THIRD_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['shift', 'backspace'],
        y: THIRD_ROW_Y,
        id: 'shiftBackspace'
    },
    {
        keys:['123', 'email','return'],
        y: FOURTH_ROW_Y,
        id: 'abcSpaceReturn'
    },
    {
        keys:['emojifull', 'dictationfull'],
        y: FIFTH_ROW_Y,
        id: 'emojiDictation'
    }
];

var alphabetDiscord = [
    {
        keys:['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
        y: FIRST_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['a','s','d','f','g','h','j','k','l'],
        y: SECOND_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['z','x','c','v','b','n','m'],
        y: THIRD_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['shift', 'backspace'],
        y: THIRD_ROW_Y,
        id: 'shiftBackspace'
    },
    {
        keys:['123', 'space', '@', '#'],
        y: FOURTH_ROW_Y,
        id: 'abcSpaceReturn'
    },
    {
        keys:['emojifull', 'dictationfull'],
        y: FIFTH_ROW_Y,
        id: 'emojiDictation'
    }
];

var keypad = [
    {
        keys: ['1','2','3'],
        extra: ['','abc', 'def'],
        y: KP_FIRST_ROW_Y,
        id: 'keypadKeys'
    },
    {
        keys: ['4','5','6'],
        extra: ['ghi', 'jkl', 'mno'],
        y: KP_SECOND_ROW_Y,
        id: 'keypadKeys',
    },
    {
        keys: ['7','8','9'],
        extra: ['pqrs', 'tuv', 'wxyz'],
        y: KP_THIRD_ROW_Y,
        id: 'keypadKeys',
    },
    {
        keys: ['','0','delete'],
        extra: ['','',''],
        y: KP_FOURTH_ROW_Y,
        id: 'keypadKeys'
    }
];
var keypadTel = [
    {
        keys: ['1','2','3'],
        extra: ['','abc', 'def'],
        y: KP_FIRST_ROW_Y,
        id: 'keypadKeys'
    },
    {
        keys: ['4','5','6'],
        extra: ['ghi', 'jkl', 'mno'],
        y: KP_SECOND_ROW_Y,
        id: 'keypadKeys',
    },
    {
        keys: ['7','8','9'],
        extra: ['pqrs', 'tuv', 'wxyz'],
        y: KP_THIRD_ROW_Y,
        id: 'keypadKeys',
    },
    {
        keys: ['#','0','delete'],
        extra: ['','',''],
        y: KP_FOURTH_ROW_Y,
        id: 'keypadKeys'
    }
];
var keypadTelDecimal = [
    {
        keys: ['1','2','3'],
        extra: ['','abc', 'def'],
        y: KP_FIRST_ROW_Y,
        id: 'keypadKeys'
    },
    {
        keys: ['4','5','6'],
        extra: ['ghi', 'jkl', 'mno'],
        y: KP_SECOND_ROW_Y,
        id: 'keypadKeys',
    },
    {
        keys: ['7','8','9'],
        extra: ['pqrs', 'tuv', 'wxyz'],
        y: KP_THIRD_ROW_Y,
        id: 'keypadKeys',
    },
    {
        keys: ['.','0','delete'],
        extra: ['','',''],
        y: KP_FOURTH_ROW_Y,
        id: 'keypadKeys'
    }
];
var keypadTelALT = [
    {
        keys: ['','',''],
        extra: ['','', ''],
        y: KP_FIRST_ROW_Y,
        id: 'keypadKeys'
    },
    {
        keys: ['pause','','wait'],
        extra: ['', '', ''],
        y: KP_SECOND_ROW_Y,
        id: 'keypadKeys',
    },
    {
        keys: ['*','','#'],
        extra: ['', '', ''],
        y: KP_THIRD_ROW_Y,
        id: 'keypadKeys',
    },
    {
        keys: ['123','+','delete'],
        extra: ['','',''],
        y: KP_FOURTH_ROW_Y,
        id: 'keypadKeys'
    }
];

var numbers = [
    {
        keys:['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
        y: FIRST_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['-','/',':',';','(',')','$','&','@', '"'],
        y: SECOND_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['.',',','?','!','`'],
        y: THIRD_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['shift', 'backspace'],
        y: THIRD_ROW_Y,
        id: 'shiftBackspace'
    },
    {
        keys:['ABC', 'space', 'return'],
        y: FOURTH_ROW_Y,
        id: 'abcSpaceReturn'
    },
    {
        keys:['emojifull', 'dictationfull'],
        y: FIFTH_ROW_Y,
        id: 'emojiDictation'
    }
];

var numberEmail = [
    {
        keys:['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
        y: FIRST_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['$','!','~','&','=','#','[',']'],
        y: SECOND_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['.','_','-','+'],
        y: THIRD_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['shift', 'backspace'],
        y: THIRD_ROW_Y,
        id: 'shiftBackspace'
    },
    {
        keys:['ABC', 'email', 'return'],
        y: FOURTH_ROW_Y,
        id: 'abcSpaceReturn'
    },
    {
        keys:['emojifull', 'dictationfull'],
        y: FIFTH_ROW_Y,
        id: 'emojiDictation'
    }
];

var numberEmailCap = [
    {
        keys:['`', '|', '{', '}', '?', '%', '^', '*', '/', "'"],
        y: FIRST_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['$','!','~','&','=','#','[',']'],
        y: SECOND_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['.','_','-','+'],
        y: THIRD_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['shift', 'backspace'],
        y: THIRD_ROW_Y,
        id: 'shiftBackspace'
    },
    {
        keys:['ABC', 'email', 'return'],
        y: FOURTH_ROW_Y,
        id: 'abcSpaceReturn'
    },
    {
        keys:['emojifull', 'dictationfull'],
        y: FIFTH_ROW_Y,
        id: 'emojiDictation'
    }
];

var numberCydiaAddSource = [
    {
        keys:['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
        y: FIRST_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['@','&','%','?',',','=','[',']'],
        y: SECOND_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['_',':','-','+'],
        y: THIRD_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['shift', 'backspace'],
        y: THIRD_ROW_Y,
        id: 'shiftBackspace'
    },
    {
        keys:['ABC', '/', 'return'],
        y: FOURTH_ROW_Y,
        id: 'abcSpaceReturn'
    },
    {
        keys:['emojifull', 'dictationfull'],
        y: FIFTH_ROW_Y,
        id: 'emojiDictation'
    }
];

var numbersPeriod = [
    {
        keys:['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
        y: FIRST_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['-','/',':',';','(',')','$','&','@', '"'],
        y: SECOND_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['.',',','?','!','`'],
        y: THIRD_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['shift', 'backspace'],
        y: THIRD_ROW_Y,
        id: 'shiftBackspace'
    },
    {
        keys:['ABC', 'space', '.', 'return'],
        y: FOURTH_ROW_Y,
        id: 'abcSpaceReturn'
    },
    {
        keys:['emojifull', 'dictationfull'],
        y: FIFTH_ROW_Y,
        id: 'emojiDictation'
    }
];

var numbersCap = [
    {
        keys:['[', ']', '{', '}', '#', '%', '^', '*', '+', '='],
        y: FIRST_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['_','\\','|','~','<','>','€','£','¥', '·'],
        y: SECOND_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['.',',','?','!','`'],
        y: THIRD_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['shiftfull', 'backspace'],
        y: THIRD_ROW_Y,
        id: 'shiftBackspace'
    },
    {
        keys:['ABC', 'space', 'return'],
        y: FOURTH_ROW_Y,
        id: 'abcSpaceReturn'
    },
    {
        keys:['emojifull', 'dictationfull'],
        y: FIFTH_ROW_Y,
        id: 'emojiDictation'
    }
];

var numberCapCydiaAddSource = [
    {
        keys:['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
        y: FIRST_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['*','$','#','!','`','^','[',']'],
        y: SECOND_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['~',';','(',')'],
        y: THIRD_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['shift', 'backspace'],
        y: THIRD_ROW_Y,
        id: 'shiftBackspace'
    },
    {
        keys:['ABC', '/', 'return'],
        y: FOURTH_ROW_Y,
        id: 'abcSpaceReturn'
    },
    {
        keys:['emojifull', 'dictationfull'],
        y: FIFTH_ROW_Y,
        id: 'emojiDictation'
    }
];

var numbersCapPeriod = [
    {
        keys:['[', ']', '{', '}', '#', '%', '^', '*', '+', '='],
        y: FIRST_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['_','\\','|','~','<','>','€','£','¥', '·'],
        y: SECOND_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['.',',','?','!','`'],
        y: THIRD_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['shiftfull', 'backspace'],
        y: THIRD_ROW_Y,
        id: 'shiftBackspace'
    },
    {
        keys:['ABC', 'space', '.', 'return'],
        y: FOURTH_ROW_Y,
        id: 'abcSpaceReturn'
    },
    {
        keys:['emojifull', 'dictationfull'],
        y: FIFTH_ROW_Y,
        id: 'emojiDictation'
    }
];

var emoji = [
    {
        keys:['clock', 'face', 'animal', 'food', 'sports', 'city', 'symbols', 'random', 'flags', '<'],
        y: EMOJI_SELECTOR_TOP_SPACING,
        id: 'emojiPickerRow'
    },
    {
        keys:['ABC', 'dictationfull'],
        y: EMOJI_SELECTOR_DICTATION_ABC,
        id: 'emojiABCDictation'
    },
]

var dictation = [
    {
        keys:['kb'],
        y: 220,
        id: 'dictation'
    },
]

function changesForMoreKeyboards(){
    if(AMOUNT_OF_KEYBOARDS >= 3){
        alphabet[4] = {
            keys:['123','emoji', 'space', 'return'],
            y: FOURTH_ROW_Y,
            id: 'abcSpaceReturn'
        };
        alphabet[5] = {
            keys:['globe', 'dictationfull'],
            y: FIFTH_ROW_Y,
            id: 'emojiDictation'
        };
        numbers[4] = {
            keys:['ABC','emoji', 'space', 'return'],
            y: FOURTH_ROW_Y,
            id: 'abcSpaceReturn'
        };
        numbers[5] = {
            keys:['globe', 'dictationfull'],
            y: FIFTH_ROW_Y,
            id: 'emojiDictation'
        };
        numbersCap[4] = {
            keys:['ABC','emoji', 'space', 'return'],
            y: FOURTH_ROW_Y,
            id: 'abcSpaceReturn'
        };
        numbersCap[5] = {
            keys:['globe', 'dictationfull'],
            y: FIFTH_ROW_Y,
            id: 'emojiDictation'
        };
    }
    //iPhone6S
    if(screen.width === 414 && screen.height === 736){
        alphabet[4] = {
            keys:['123','emoji', 'dictationfull', 'space', 'return'],
            y: FOURTH_ROW_Y,
            id: 'abcSpaceReturn'
        };
        alphabet[5] = {
            keys:[],
            y: FIFTH_ROW_Y,
            id: 'emojiDictation'
        };
        numbers[4] = {
            keys:['ABC','emoji', 'dictationfull', 'space', 'return'],
            y: FOURTH_ROW_Y,
            id: 'abcSpaceReturn'
        };
        numbers[5] = {
            keys:[],
            y: FIFTH_ROW_Y,
            id: 'emojiDictation'
        };
        numbersCap[4] = {
            keys:['ABC','emoji', 'dictationfull', 'space', 'return'],
            y: FOURTH_ROW_Y,
            id: 'abcSpaceReturn'
        };
        numbersCap[5] = {
            keys:[],
            y: FIFTH_ROW_Y,
            id: 'emojiDictation'
        };
        if(AMOUNT_OF_KEYBOARDS >= 3){

        }
    }
    //iPhone6
    if(screen.width === 375 && screen.height === 667){
        alphabet[4] = {
            keys:['123','emoji', 'dictationfull', 'space', 'return'],
            y: FOURTH_ROW_Y,
            id: 'abcSpaceReturn'
        };
        alphabet[5] = {
            keys:[],
            y: FIFTH_ROW_Y,
            id: 'emojiDictation'
        };
        numbers[4] = {
            keys:['ABC','emoji', 'dictationfull', 'space', 'return'],
            y: FOURTH_ROW_Y,
            id: 'abcSpaceReturn'
        };
        numbers[5] = {
            keys:[],
            y: FIFTH_ROW_Y,
            id: 'emojiDictation'
        };
        numbersCap[4] = {
            keys:['ABC','emoji', 'dictationfull', 'space', 'return'],
            y: FOURTH_ROW_Y,
            id: 'abcSpaceReturn'
        };
        numbersCap[5] = {
            keys:[],
            y: FIFTH_ROW_Y,
            id: 'emojiDictation'
        };
        if(AMOUNT_OF_KEYBOARDS >= 3){
            
        }
    }
    //iPhone5
    if(screen.width === 320 && screen.height === 568){
        alphabet[4] = {
            keys:['123','emoji', 'dictationfull', 'space', 'return'],
            y: FOURTH_ROW_Y,
            id: 'abcSpaceReturn'
        };
        alphabet[5] = {
            keys:[],
            y: FIFTH_ROW_Y,
            id: 'emojiDictation'
        };
        numbers[4] = {
            keys:['ABC','emoji', 'dictationfull', 'space', 'return'],
            y: FOURTH_ROW_Y,
            id: 'abcSpaceReturn'
        };
        numbers[5] = {
            keys:[],
            y: FIFTH_ROW_Y,
            id: 'emojiDictation'
        };
        numbersCap[4] = {
            keys:['ABC','emoji', 'dictationfull', 'space', 'return'],
            y: FOURTH_ROW_Y,
            id: 'abcSpaceReturn'
        };
        numbersCap[5] = {
            keys:[],
            y: FIFTH_ROW_Y,
            id: 'emojiDictation'
        };
        if(AMOUNT_OF_KEYBOARDS >= 3){

        }
    }
}
changesForMoreKeyboards();
