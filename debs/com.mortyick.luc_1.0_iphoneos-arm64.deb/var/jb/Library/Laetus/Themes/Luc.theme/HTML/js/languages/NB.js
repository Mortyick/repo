var alphabetNB = [
    {
        keys:['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p','å'],
        y: FIRST_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['a','s','d','f','g','h','j','k','l','ø','æ'],
        y: SECOND_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['z','x','c','v','b','n','m'],
        y: THIRD_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['shift', 'backspace'],
        y: THIRD_ROW_Y,
        id: 'shiftBackspace'
    },
    {
        keys:['123', 'space', 'return'],
        y: FOURTH_ROW_Y,
        id: 'abcSpaceReturn'
    },
    {
        keys:['emojifull', 'dictationfull'],
        y: FIFTH_ROW_Y,
        id: 'emojiDictation'
    }
];
var numbersNB = [
    {
        keys:['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
        y: FIRST_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['-','/',':',';','(',')','$','&','@', '"'],
        y: SECOND_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['.',',','?','!','`'],
        y: THIRD_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['shift', 'backspace'],
        y: THIRD_ROW_Y,
        id: 'shiftBackspace'
    },
    {
        keys:['ABC', 'space', 'return'],
        y: FOURTH_ROW_Y,
        id: 'abcSpaceReturn'
    },
    {
        keys:['emojifull', 'dictationfull'],
        y: FIFTH_ROW_Y,
        id: 'emojiDictation'
    }
];
var numbersCapNB = [
    {
        keys:['[', ']', '{', '}', '#', '%', '^', '*', '+', '='],
        y: FIRST_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['_','\\','|','~','<','>','€','£','¥', '·'],
        y: SECOND_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['.',',','?','!','`'],
        y: THIRD_ROW_Y,
        id: 'standardKeys'
    },
    {
        keys:['shiftfull', 'backspace'],
        y: THIRD_ROW_Y,
        id: 'shiftBackspace'
    },
    {
        keys:['ABC', 'space', 'return'],
        y: FOURTH_ROW_Y,
        id: 'abcSpaceReturn'
    },
    {
        keys:['emojifull', 'dictationfull'],
        y: FIFTH_ROW_Y,
        id: 'emojiDictation'
    }
];
