
function addFlashKey(div){
    div.classList.add('keyBGRandom');
    setTimeout(function(){
        div.classList.remove('keyBGRandom');
    },100);
}

var count = 0;
function getRandomNumberBetween(start, end){
    return Math.floor(Math.random() * end + start);
}
function animateAmount(classes, classLength){
    var amount = 5;
    for (let index = 0; index < 5; index++) {
        setTimeout(function(){
            addFlashKey(classes[getRandomNumberBetween(0, classLength)]);
        }, 200);
    }
}
function randomFlash(){
    count++
    if(count <= 10){
        var classes = document.getElementsByClassName('keyBG');
        var classLength = classes.length;
        animateAmount(classes, classLength);
        setTimeout(function(){
            randomFlash();
        },200);
    }else{
        count = 0;
        setTimeout(function(){
            randomFlash();
        },5000);
    }
}

//change to onload
setTimeout(function(){
    randomFlash();
},10);
