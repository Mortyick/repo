function onload(){
    settings();
    api.weather.observeData(function(newData) {
        weathercheck(newData);
    });
}

function set_date_1(num, dbl) {
    var num1 = $("#num_1");
    var num1s = $("#num_shadow_s_1");
    var num1l = $("#num_shadow_l_1");

    num1.removeClass().addClass("num n" + num);
    num1s.removeClass().addClass("shadow_s n" + num);
    num1l.removeClass().addClass("shadow_l n" + num);

    if (dbl) {
        num1.addClass("double");
        num1s.addClass("double");
        num1l.addClass("double");
    }
}

function set_date_2(num) {
    var num2 = $("#num_2");
    var num2s = $("#num_shadow_s_2");
    var num2l = $("#num_shadow_l_2");

    num2.removeClass().addClass("num n" + num);
    num2s.removeClass().addClass("shadow_s n" + num);
    num2l.removeClass().addClass("shadow_l n" + num);
}


function set_hour_1(num, dbl) {
    var num1 = $("#num_hour");
    var num1s = $("#num_shadow_s_hour");
    var num1l = $("#num_shadow_l_hour");

    num1.removeClass().addClass("num n" + num);
    num1s.removeClass().addClass("shadow_s n" + num);
    num1l.removeClass().addClass("shadow_l n" + num);

    if (dbl) {
        num1.addClass("double");
        num1s.addClass("double");
        num1l.addClass("double");
    }
}

function set_hour_2(num) {
    var num2 = $("#num_hour_2");
    var num2s = $("#num_shadow_s_hour_2");
    var num2l = $("#num_shadow_l_hour_2");

    num2.removeClass().addClass("num n" + num);
    num2s.removeClass().addClass("shadow_s n" + num);
    num2l.removeClass().addClass("shadow_l n" + num);
}

function set_min_1(num, dbl) {
    var num1 = $("#num_min");
    var num1s = $("#num_shadow_s_min");
    var num1l = $("#num_shadow_l_min");

    num1.removeClass().addClass("num n" + num);
    num1s.removeClass().addClass("shadow_s n" + num);
    num1l.removeClass().addClass("shadow_l n" + num);

    if (dbl) {
        num1.addClass("double");
        num1s.addClass("double");
        num1l.addClass("double");
    }
}

function set_min_2(num) {
    var num2 = $("#num_min_2");
    var num2s = $("#num_shadow_s_min_2");
    var num2l = $("#num_shadow_l_min_2");

    num2.removeClass().addClass("num n" + num);
    num2s.removeClass().addClass("shadow_s n" + num);
    num2l.removeClass().addClass("shadow_l n" + num);
}


function toggle_date_2(show) {
    $("#num_shadow_l_2").toggle(show);
    $("#num_shadow_s_2").toggle(show);
    $("#num_2").toggle(show);
}

function toggle_clock(show) {
    $("#num_shadow_l_hour_2").toggle(show);
    $("#num_shadow_s_hour_2").toggle(show);
    $("#num_hour_2").toggle(show);
    $("#num_shadow_l_min_2").toggle(show);
    $("#num_shadow_s_min_2").toggle(show);
    $("#num_min_2").toggle(show);
    $("#num_shadow_l_hour").toggle(show);
    $("#num_shadow_s_hour").toggle(show);
    $("#num_hour").toggle(show);
    $("#num_shadow_l_min").toggle(show);
    $("#num_shadow_s_min").toggle(show);
    $("#num_min").toggle(show);
}

function settings(){
    document.documentElement.style.setProperty("--anim-speed", animspeed);
    document.documentElement.style.setProperty("--scale", scle);

    if (clockoff == true){
        toggle_clock(false);
    }

    if (animoff == true){
    document.documentElement.style.setProperty("--anim-speed", "-1s");
    }
}

clock({
  twentyfour : !!twentyfour,
  padzero : false,
  refresh : 1000,
  success: function(clock){
    var now = moment();
    var hour = clock.hour();
    var min = clock.minute();
    var month = now.format("MMM").toLowerCase();
    var date = clock.date();
    var datedig = date.toString().split('');
    var hourdig = hour.toString().split('');
    var mindig = min.toString().split('');
    var dayofweek = now.format("dddd").toLowerCase();
    var tod = "morning";

    // modify month
    var calendar = $("#cal");
    calendar.removeClass().addClass(month);

    var isdbldigit = datedig.length > 1

    set_date_1(datedig[0], isdbldigit);

    if (isdbldigit) {
        set_date_2(datedig[1]);
        toggle_date_2(true);
    } else {
        toggle_date_2(false);
    }

    var hourdbl = hourdig.length > 1

    if (hourdbl) {
        set_hour_1(hourdig[0], hourdbl);
        set_hour_2(hourdig[1]);
    } else {
        set_hour_1("0", hourdbl);
        set_hour_2(hourdig[0], hourdbl);
    }

    var mindbl = mindig.length > 1

    if (mindbl) {
        set_min_1(mindig[0], mindbl);
        set_min_2(mindig[1], mindbl);
    } else {
        set_min_1("0", mindbl);
        set_min_2(mindig[0], mindbl);
    }

    var day = $("#day");
    day.removeClass().addClass(dayofweek);

    var hour = now.hour();
    if (hour < 5) {
        tod = "midnight";
    } else if (hour < 10) {
        tod = "morning";
    } else if (hour < 12) {
        tod = "bnoon";
    } else if (hour < 18) {
        tod = "anoon";
    } else {
        tod = "night";
    }

    $("#time").removeClass().addClass(tod);
  }
});

var cloud = [19, 20, 21, 22, 25, 26, 28, 30, 44];
var sun = [23, 24, 27, 29, 31, 32, 33, 34, 36];
var rain = [0, 1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 17, 18, 35, 37, 38, 39, 40, 45, 47];
var snow = [7, 13, 14, 15, 16, 41, 42, 43, 46];

function weathercheck(data){
    var weatherC = "";
    var cond = data.now.condition.code;
    if (cloud.includes(cond) == true) {
                weatherC = "cloud";
    } else if (sun.includes(cond) == true) {
                weatherC = "sun";
    } else if (rain.includes(cond) == true) {
                weatherC = "rain";
    } else if (snow.includes(cond) == true) {
                weatherC = "snow";
    }
    if (weatherC) {
         $("#weather").removeClass().addClass(weatherC);
    }
}